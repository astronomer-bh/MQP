# Robot

## Required Packages

~~~~
sudo apt-get install python-pip python3-pip
sudo -H python3 -m pip install --upgrade pip 
sudo -H python3 -m pip install pyserial sympy 
~~~~
